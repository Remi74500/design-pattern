package com.tetras.librairie;

public class CircuitDuChampionnat {
    
    public CircuitDuChampionnat(){

        //
        VoitureF1Factory.getVoitureF1(ConstructeurType.MCLAREN);
        VoitureF1Factory.getVoitureF1(ConstructeurType.ALPINE);
        VoitureF1Factory.getVoitureF1(ConstructeurType.FERRARI);

        
    }
}
