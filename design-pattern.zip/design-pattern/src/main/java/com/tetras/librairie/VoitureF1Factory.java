package com.tetras.librairie;

public class VoitureF1Factory {


    public static IVoitureChampionnatF1 getVoitureF1(ConstructeurType type){

        if(ConstructeurType.MCLAREN.equals(type)){
            return new McLaren();
        }
        else if(ConstructeurType.ALPINE.equals(type)){
            return new Alpine();
        }
        else if(ConstructeurType.FERRARI.equals(type)){
            return new Ferrari();
        }
        
        else throw new IllegalArgumentException();

        
    }

    private VoitureF1Factory() {
        
    }

    

}
