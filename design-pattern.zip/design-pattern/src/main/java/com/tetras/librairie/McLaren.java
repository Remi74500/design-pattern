package com.tetras.librairie;

public class McLaren implements IVoitureChampionnatF1 {
    
    private String couleur = "Orange";

    public void accelerer(){
        //
    }
    public void tourner(){
        //
    }
    public void freiner(){
        //
    }

    public String getColor(){
        return couleur;
    } 
}
