package com.tetras.librairie;

public class Alpine implements IVoitureChampionnatF1{

    private String couleur = "Bleu";

    public void accelerer(){
        //
    }
    public void tourner(){
        //
    }
    public void freiner(){
        //
    }

    public String getColor(){
        return couleur;
    } 

    
    
}
