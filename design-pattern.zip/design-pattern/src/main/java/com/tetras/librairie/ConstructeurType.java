package com.tetras.librairie;

public enum ConstructeurType {
    
    MCLAREN, ALPINE, FERRARI;   
}
