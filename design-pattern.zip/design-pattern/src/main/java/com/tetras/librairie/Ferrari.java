package com.tetras.librairie;

public class Ferrari implements IVoitureChampionnatF1{
    
    private String couleur = "Rouge";

    public void accelerer(){
        //
    }
    public void tourner(){
        //
    }
    public void freiner(){
        //
    }

    public String getColor(){
        return couleur;
    } 

}
