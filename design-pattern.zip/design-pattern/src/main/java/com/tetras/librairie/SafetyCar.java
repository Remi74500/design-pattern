package com.tetras.librairie;

public class SafetyCar implements IVoitureChampionnatF1{
    
    private static SafetyCar instance = new SafetyCar();

    public SafetyCar(){

        getInstance();
    }

    public static SafetyCar getInstance(){
        return instance;
    }

    public void accelerer(){
        //
    }
    public void tourner(){
        //
    }
    public void freiner(){
        //
    }

    public String getColor(){
         return "Grise";
    }

    
}
