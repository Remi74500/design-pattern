package com.tetras.librairie;

public interface IVoitureChampionnatF1 {
    
    void accelerer();
    void tourner();
    void freiner();
    
    String getColor();
    
}
