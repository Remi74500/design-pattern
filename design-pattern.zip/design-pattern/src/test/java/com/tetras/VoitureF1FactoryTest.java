package com.tetras;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.tetras.librairie.Alpine;
import com.tetras.librairie.ConstructeurType;
import com.tetras.librairie.Ferrari;
import com.tetras.librairie.IVoitureChampionnatF1;
import com.tetras.librairie.McLaren;
import com.tetras.librairie.VoitureF1Factory;

import org.junit.jupiter.api.Test;

public class VoitureF1FactoryTest {
    


    public void assertFormule1(IVoitureChampionnatF1 F1){  

        F1.accelerer();
        F1.freiner();
        F1.tourner();

    }

    @Test
    public void testMcLaren(){
        IVoitureChampionnatF1 F1 = VoitureF1Factory.getVoitureF1(ConstructeurType.MCLAREN);
        assertTrue(F1 instanceof McLaren);      // Type OK
        assertEquals( "Orange", F1.getColor()); // Couleur OK
        assertFormule1(F1);
    }

    @Test
    public void testFerrari(){
        IVoitureChampionnatF1 F1 = VoitureF1Factory.getVoitureF1(ConstructeurType.FERRARI);
        assertTrue(F1 instanceof Ferrari);      // Type OK
        assertEquals( "Rouge", F1.getColor());  // Couleur OK
        assertFormule1(F1);
    }

    @Test
    public void testAlpine(){
        IVoitureChampionnatF1 F1 = VoitureF1Factory.getVoitureF1(ConstructeurType.ALPINE);
        assertTrue(F1 instanceof Alpine);       // Type OK 
        assertEquals("Bleu", F1.getColor());    // Couleur OK
        
        assertFormule1(F1);
    }
}
