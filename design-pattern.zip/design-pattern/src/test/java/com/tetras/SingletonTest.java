package com.tetras;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.tetras.librairie.SafetyCar;

import org.junit.jupiter.api.Test;

public class SingletonTest {
    
    @Test

    void testSafetyCar() {
        //
        SafetyCar Car1 = SafetyCar.getInstance();
        SafetyCar Car2 = SafetyCar.getInstance();

        assertEquals(Car1, Car2);
        

    }
}
